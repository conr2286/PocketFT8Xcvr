#pragma once

// Define the data type used for x/y pixel coordinates and width/height.  Values need
// to range anywhere from 0 to the size of the screen.
typedef unsigned short ACoord;   // Coordinate type
typedef unsigned short ALength;  // A length (e.g. width or height)