#pragma once

void set_startup_freq(void);
