# Famous sketches and kits from third parties based on this Library



* [ATS-20 / ATS-20+  from AliExpress / Amazon/ eBay](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/AliExpress)
* [Gert Baak](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/GERT_BAAK)
* [LilyGO T-Embed](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/Lilygo_t_embed)
* [TTGO T-Display by Ralph Xavier](https://github.com/ralphxavier/SI4735)
* [David Martins](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/DAVID_MARTINS) 
* [Felix Angga](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/FELIX_ANGGA)
* [Plamen](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/PLAMEN)
* [Thiago Lima](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/THIAGO_LIMA)
* [PU2CLR simple interface](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_KITS/ESP32_ALL_IN_ONE_TFT_TOUTC_PU2CLR)

