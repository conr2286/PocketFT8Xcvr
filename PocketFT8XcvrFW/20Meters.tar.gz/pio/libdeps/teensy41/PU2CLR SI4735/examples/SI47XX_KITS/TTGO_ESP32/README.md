# TTGO ESP32

The TTGO T-Display a board based on the ESP32 integrated with a built-in 1.14 inch TFT display. ([click here for more details about this board](https://github.com/Xinyuan-LilyGO/TTGO-T-Display))

## TTGO T-Display, SI473X and PU2CLR SI4735 Arduino Library

You can check out a really beatiful application using the TTGO T-Display and the PU2CLR SI4735 Arduino Library by checking  [Ralph Xavier github repository](https://github.com/ralphxavier/SI4735).






