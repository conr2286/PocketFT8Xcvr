# Proof of Concept for SI4735 Arduino Library and ATtiny85 

Test and validation of the SI4735 Arduino Library on ATtiny85.
It is a simple FM radio implementation. 
This sketch has been successfully tested on __ATtiny85__