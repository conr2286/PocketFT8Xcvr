WARNING:  test_time is currently a work in progress and its results may be invalid.
